from flask import Flask, render_template, request, jsonify
import requests
import json
import re
from string import digits

app = Flask(__name__)

url = "https://bscscan.com"

@app.route('/')
def index():
    return render_template('dashboard.html', is_search="no-searchbar", active_page="dashboard")

@app.route('/address/<string:term>')
def address(term):
    response = requests.get("https://bscscan.com/searchHandler?term="+term+"&filterby=2")
    json_data = json.loads(response.content)
    # print(json_data)

    search_data=[]

    for list in json_data:
        split_value = list.split("\t",2)
        
        split_name = split_value[0]
        split_address = split_value[1]

        value_price = split_value[2].split("$")[-1]
        value_price_again = value_price.split("\t")[0]
        
        # SPLIT IMAGE
        split_image = split_value[-1].split()
        join_image = ''.join(split_image)
        trim_image = join_image.split("~",1)
        trim_image_again = trim_image[-1]
        
        image_extension = trim_image_again.split(".")[-1]

        if image_extension == "png":
            trim_image_name = trim_image_again.split(".")[-2]
            image_name = trim_image_name.lstrip(digits)
            trim_image_again = "https://bscscan.com/token/images/"+image_name+".png"
        else:
            trim_image_again = "images/default-coin.png"
        
        search_data.append({"name": split_name, "address": split_address, "image": trim_image_again, "price": value_price_again})

        
        print(value_price_again)

    return jsonify(search_data[1:])

@app.route('/dashboard.html')
def dashboard():
    return render_template('dashboard.html', is_search="no-searchbar", active_page="dashboard")

@app.route('/live_charts.html')
def live_charts():

    return render_template('live_charts.html', active_page="live-chart")

@app.route('/stop_losses.html')
def stop_losses():
    return render_template('stop_losses.html', active_page="stop-loss")

@app.route('/sniper.html')
def sniper():
    return render_template('sniper.html', active_page="sniper")

@app.route('/swap_token.html')
def swap_token():
    return render_template('swap_token.html', active_page="swap-token")

if __name__ == "__main__":
    app.run(debug=True, port=3000)